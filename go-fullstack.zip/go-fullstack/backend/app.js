const express = require('express');
const bodyParser = require('body-parser')
const mongoose = require('mongoose');

const Thing = require('./models/Thing.js');


const app = express();


mongoose.set('strictQuery', false);
mongoose.connect('mongodb+srv://prince:prince1235@cluster0.uhtueec.mongodb.net/?retryWrites=true&w=majority',
  { useNewUrlParser: true,
    useUnifiedTopology: true })
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch(() => console.log('Connexion à MongoDB échouée !'));

  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    next();
  });


  app.use('/api/stuff', (req, res, next) => {
    const stuff = [
      {
        _id: 'oeihfzeoi',
        title: '1',
        description: 'Les infos de mon premier objet',
        imageUrl: 'https://cdn.pixabay.com/photo/2019/06/11/18/56/camera-4267692_1280.jpg',
        price: 4900,
        userId: 'qsomihvqios',
      },
      {
        _id: 'oeihfzeomoihi',
        title: '2',
        description: 'Les infos de mon deuxième objet',
        imageUrl: 'https://cdn.pixabay.com/photo/2019/06/11/18/56/camera-4267692_1280.jpg',
        price: 2900,
        userId: 'qsomihvqios',
      },

      {
        _id: 'oeihfzeomoihi',
        title: '3',
        description: 'Les infos de mon deuxième objet',
        imageUrl: 'https://images.pexels.com/photos/4587971/pexels-photo-4587971.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        price: 2900,
        userId: 'qsomihvqios',
      },

      {
        _id: 'oeihfzeomoihi',
        title: '4',
        description: 'Les infos de mon deuxième objet',
        imageUrl: 'https://images.pexels.com/photos/8496566/pexels-photo-8496566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        price: 2900,
        userId: 'qsomihvqios',
      },
    ];
    res.status(200).json(stuff);
  });

  

module.exports = app;